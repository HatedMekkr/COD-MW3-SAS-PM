!WARNING!
For this you need Sprops addon.
Link: https://steamcommunity.com/sharedfiles/filedetails/?id=173482196 ;

Tried to make an accurate model of the iDroid from MGSVTPP (I tried).

Has an on and off interface with Spawnmenu image.
(To use this feature - you need to type the command "bind KEY+pac_events" into the console.)

Enjoy!

My steam: https://steamcommunity.com/id/HatedMekkr/ ;
My Github: https://github.com/HatedMekkr/HatedMekkrBasement/tree/main ;